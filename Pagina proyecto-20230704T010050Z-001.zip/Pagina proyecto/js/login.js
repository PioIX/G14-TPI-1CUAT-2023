let idUser=1;
class User{
    constructor(username, password, nombre, apellido){
        this.id=idUser;
        idUser++
        this.username=username;
        this.password=password;
        this.nombre = nombre;
        this.apellido = apellido;
    }
}

const usuarios = []
usuarios.push(new User("1", "1", "1", "1", "1" ))
usuarios.push(new User("uchemasters", "chongo", "Uche", "Chong"))
usuarios.push(new User("mcarrere", "river", "Manuel", "Carrere"))
usuarios.push(new User("toto", "feiji", "Tomás", "Feijoo"))
usuarios.push(new User("markilocuras", "silbar", "Marcos", "Silveira"))
usuarios.push(new User("dieguipro", "10", "Diego", "Castelucci"))


let userId = -1

function userExist(username, password) {
    for (let i in usuarios ) {
        console.log(usuarios[i])
        if (usuarios[i].username == username) {
            if (usuarios[i].password == password) {
                userId = usuarios[i].id
            return 1
        } 
            else {
            return 0
        }
    }
    
    }
    return -1
}

function ingresar() {
    let user = getUser();
    let password = getPassword();
    let resultado = userExist(user, password);
     if (resultado == 1) {
        changeScreen();
     } 
     else if (resultado == 0) {
        alert("La contraseña no es correcta");
     } 
     else {
        alert("El usuario no existe");
     }
     
}

function registrerNewUser(username, password) {
    for (let i in users ) {
        console.log(users[i])
        if (users[i].username == username) {
            return false
           } 
    }
    usuarios.push(new User(username, password, nombre, apellido))
    return true
}

function register() {
    let newU = getUser();
    let newP = getPassword();
    let result = registrerNewUser(newU, newP);
    if (result == true) {
        console.log(usuarios)
        enter();
    } else {
        alert("El usuario ya existe")
    }
}

